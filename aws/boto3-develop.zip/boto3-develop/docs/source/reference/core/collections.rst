.. _ref_core_collections:

=====================
Collections Reference
=====================

.. automodule:: boto3.resources.collection
   :members:
   :undoc-members:
